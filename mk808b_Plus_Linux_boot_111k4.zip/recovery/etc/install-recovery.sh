#!/system/bin/sh
if ! applypatch -c MTD:recovery:8301794:9fd8976ad1b407ccdc66531108937604a5644741; then
  log -t recovery "Installing new recovery image"
  applypatch -b /system/etc/recovery-resource.dat MTD:boot:7149555:7a09da23d344cb3b95b99b295262464249b42057 MTD:recovery 9fd8976ad1b407ccdc66531108937604a5644741 8301794 7a09da23d344cb3b95b99b295262464249b42057:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
